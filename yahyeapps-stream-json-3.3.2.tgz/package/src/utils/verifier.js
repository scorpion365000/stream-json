// @ts-self-types="./verifier.d.ts"

import {asStream} from '@yahyeapps/stream-chain';
import {asWebStream} from '@yahyeapps/stream-chain/web';

import factory from '../core/utils/verifier.js';

/** @type {any} */ (factory).asStream = options => asStream(factory(options), {writableObjectMode: true, readableObjectMode: true, ...options});
/** @type {any} */ (factory).asWebStream = options => asWebStream(factory(options), {writableObjectMode: true, readableObjectMode: true, ...options});

export default factory;
export {factory as verifier};
export * from '../core/utils/verifier.js';
