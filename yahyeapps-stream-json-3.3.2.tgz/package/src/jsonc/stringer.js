// @ts-self-types="./stringer.d.ts"

import {asStream} from '@yahyeapps/stream-chain';
import {asWebStream} from '@yahyeapps/stream-chain/web';

import factory from '../core/jsonc/stringer.js';

/** @type {any} */ (factory).asStream = options => asStream(factory(options), {writableObjectMode: true, readableObjectMode: true, ...options});
/** @type {any} */ (factory).asWebStream = options => asWebStream(factory(options), {writableObjectMode: true, readableObjectMode: true, ...options});

export default factory;
export {factory as jsoncStringer, factory as stringer};
export * from '../core/jsonc/stringer.js';
