// @ts-self-types="./verifier.d.ts"

import {asWebStream} from '@yahyeapps/stream-chain/web';

import factory from '../../core/jsonc/verifier.js';

/** @type {any} */ (factory).asWebStream = options => asWebStream(factory(options), {writableObjectMode: true, readableObjectMode: true, ...options});

export default factory;
export {factory as verifier};
export * from '../../core/jsonc/verifier.js';
