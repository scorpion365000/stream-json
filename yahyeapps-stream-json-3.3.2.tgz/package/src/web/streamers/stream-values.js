// @ts-self-types="./stream-values.d.ts"

import {asWebStream} from '@yahyeapps/stream-chain/web';

import factory from '../../core/streamers/stream-values.js';
import withParser from '../utils/with-parser.js';

/** @type {any} */ (factory).asWebStream = options => asWebStream(factory(options), {writableObjectMode: true, readableObjectMode: true, ...options});
/** @type {any} */ (factory).withParser = options => withParser(factory, {packKeys: true, jsonStreaming: true, ...options});
/** @type {any} */ (factory).withParserAsWebStream = options =>
  /** @type {any} */ (withParser).asWebStream(factory, {packKeys: true, jsonStreaming: true, ...options});

export default factory;
export {factory as streamValues};
export * from '../../core/streamers/stream-values.js';
